import { IConvertExpenseRule } from "../interfaces";

const conversionRules: IConvertExpenseRule[] = [
  { match: "Fee Electronic transaction", Category: "Bank", Subcategory: "Fee" },
  { match: "INTERAC e-Transfer fee", Title: "INTERAC Fee", Category: "Bank", Subcategory: "Fee" },
  { match: "Overdraft interest", Category: "Bank", Subcategory: "Fee" },
  { match: "ATM withdrawal", Title: "ATM withdrawal", Category: "Bank", Subcategory: "Withdrawal" },
  { match: "Online Transfer to Deposit Account", Category: "Bank", Subcategory: "Self Transfer" },

  { match: "WOODYS", Title: "Woody's", Category: "Events", Subcategory: "Club" },
  { match: "PAUPERS PUB", Title: "Paupers Pub", Category: "Events", Subcategory: "Club" },
  { match: "REBEL NIGHTCLUB", Title: "Rebel Nightclub", Category: "Events", Subcategory: "Club" },
  { match: "EVENTBRITE/QUEC", Title: "Eventbrite", Category: "Events", Subcategory: "Club" },
  { match: "TICKETWEB CANAD", Title: "Ticketweb Canada", Category: "Events", Subcategory: "Club" },
  { match: "NIAGARA SPEEDWA", Title: "Niagara Speedway", Category: "Events", Subcategory: "Travel" },
  { match: "WONDERLAND", Title: "Canada's Wonderland", Category: "Events", Subcategory: "Travel" },
  { match: "Needzappy Canad", Title: "Needzappy (Rent Charger)", Category: "Events", Subcategory: "Travel" },

  { match: "MANDARIN YONGE", Title: "Mandarim", Category: "Events", Subcategory: "Restaurant" },
  { match: "RIO 40 DEGREES", Title: "Mandarim", Category: "Events", Subcategory: "Restaurant" },
  { match: "MEZCALERO", Title: "Mezcalero", Category: "Events", Subcategory: "Restaurant" },

  { match: "PRES/", Title: "Presto", Category: "Transport", Subcategory: "TTC" },
  { match: "PRESTO ", Title: "Presto", Category: "Transport", Subcategory: "TTC" },
  { match: "LYFT", Title: "Lyft", Category: "Transport", Subcategory: "App" },
  { match: "UBER* PENDING", Title: "Uber", Category: "Transport", Subcategory: "App" },
  { match: "UBER* TRIP", Title: "Uber", Category: "Transport", Subcategory: "App" },

  { match: "LCBO/", Title: "LCBO", Category: "Drugs", Subcategory: "Alcohol" },
  { match: "THE BEER STORE", Title: "The Beer Store", Category: "Drugs", Subcategory: "Alcohol" },
  { match: "Wine Rack", Title: "Wine Rack", Category: "Drugs", Subcategory: "Alcohol" },

  { match: "THE HUNNY POT", Title: "The Hunny Pot", Category: "Drugs", Subcategory: "Weed" },
  { match: "THE BURNING BUS", Title: "The Burning Bush", Category: "Drugs", Subcategory: "Weed" },
  { match: "VALUE BUDS", Title: "Value Buds", Category: "Drugs", Subcategory: "Weed" },
  { match: "VALUD BUDS WEST", Title: "Value Buds", Category: "Drugs", Subcategory: "Weed" },
  { match: "FIKA LOCAL", Title: "Fika", Category: "Drugs", Subcategory: "Weed" },
  { match: "DAY N NITE CANN", Title: "Day N Nite", Category: "Drugs", Subcategory: "Weed" },

  { match: "APPLE.COM/BILL", Title: "", Category: "Services", Subcategory: "App" },
  { match: "Amazon.ca Prime", Title: "Amazon Prime", Category: "Services", Subcategory: "App" },
  { match: "UBER CANADA", Title: "Uber (Ride/Eats)", Category: "Services", Subcategory: "App" },

  // Bills
  { match: "CANADIAN TIRE", Title: "Canadian Tire", Category: "Bills", Subcategory: "Office" },
  { match: "aliexpress", Title: "Aliexpress", Category: "Bills", Subcategory: "Office" },
  { match: "STAPLES", Title: "Staples", Category: "Bills", Subcategory: "Office" },
  { match: "AMZN Mktp", Title: "Amazon", Category: "Bills", Subcategory: "Office" },
  { match: "Amazon.ca", Title: "Amazon", Category: "Bills", Subcategory: "Office" },
  { match: "PRICE WAR", Title: "Price War", Category: "Bills", Subcategory: "Office" },

  { match: "VALUE VILLAGE", Title: "Value Village", Category: "Bills", Subcategory: "Clothes" },

  { match: "CAPITAL ONE", Title: "Capital One", Category: "Bills", Subcategory: "Credit Card" },

  { match: "SHOPPERS DRUG M", Title: "Shoppers", Category: "Bills", Subcategory: "Pharmacy" },

  { match: "ESSO CIRCLE", Title: "Esso Circle", Category: "Bills", Subcategory: "Grocery" },
  { match: "CIRCLE K", Title: "Circle K", Category: "Bills", Subcategory: "Grocery" },
  { match: "7 ELEVEN STORE", Title: "7 Eleven Store", Category: "Bills", Subcategory: "Grocery" },
  { match: "DAMIANO'S NF", Title: "No Frills", Category: "Bills", Subcategory: "Grocery" },
  { match: "GINO'S NF", Title: "No Frills", Category: "Bills", Subcategory: "Grocery" },
  { match: "LISTRO'S NO FRI", Title: "No Frills", Category: "Bills", Subcategory: "Grocery" },
  { match: "TONE TAI SUPERM", Title: "Tone Tai", Category: "Bills", Subcategory: "Grocery" },
  { match: "FRESHCO", Title: "FreshCo", Category: "Bills", Subcategory: "Grocery" },
  { match: "SAM'S FOOD STOR", Title: "Sam's Food", Category: "Bills", Subcategory: "Grocery" },
  { match: "DOLLARAMA", Title: "Dollarama", Category: "Bills", Subcategory: "Grocery" },
  { match: "COSTCO", Title: "Costco", Category: "Bills", Subcategory: "Grocery" },
  { match: "WALMART", Title: "Walmart", Category: "Bills", Subcategory: "Grocery" },
  { match: "LOBLAWS", Title: "Loblaws", Category: "Bills", Subcategory: "Grocery" },
  { match: "GATEWAY NEWSSTA", Title: "Gateway Newsstand (Egl)", Category: "Bills", Subcategory: "Grocery" },
  { match: "THREE STAR VARI", Title: "Three Star Variety", Category: "Bills", Subcategory: "Grocery" },

  { match: "FREEDOM MOBILE", Title: "Freedom Mobile", Category: "Bills", Subcategory: "Phone" },

  { match: "BURGER KING", Title: "Burguer King", Category: "Food", Subcategory: "App" },
  { match: "OSMOWS", Title: "Osmow's", Category: "Food", Subcategory: "App" },
  { match: "MCDONALD'S", Title: "McDonald's", Category: "Food", Subcategory: "App" },
  { match: "UBER* EATS", Title: "Uber Eats", Category: "Food", Subcategory: "App" },
  { match: "DOORDASH", Title: "DoorDash", Category: "Food", Subcategory: "App" },
  { match: "WENDYS 6758", Title: "Wendy's", Category: "Food", Subcategory: "App" },
  { match: "NYF3234", Title: "New York Fries", Category: "Food", Subcategory: "App" },
  { match: "SQ *HAPPY BURGE", Title: "Happy Burger", Category: "Food", Subcategory: "App" },
  { match: "STARBUCKS COFFE", Title: "Starbucks", Category: "Food", Subcategory: "App" },
  { match: "TACO BELL", Title: "Taco Bell", Category: "Food", Subcategory: "App" },
  { match: "ROLL STAR SUSHI", Title: "Roll Star Sushi", Category: "Food", Subcategory: "App" },
  { match: "PIZZA PIZZA", Title: "Pizza Pizza", Category: "Food", Subcategory: "App" },
  { match: "TIM HORTONS", Title: "Tim Hortons", Category: "Food", Subcategory: "App" },
  { match: "OLD.K CHICKEN", Title: "Old K Chicken", Category: "Food", Subcategory: "App" },
  { match: "JIMMY THE GREEK", Title: "Jimmy The Greek", Category: "Food", Subcategory: "App" },

  { match: "Payroll Deposit SPOT", Title: "SpotDog", Category: "Wage", Subcategory: "Dog" },
  { match: "Deposit interest", Category: "Wage", Subcategory: "Investment" },
  { match: "Bonus deposit interest", Category: "Wage", Subcategory: "Investment" },
  { match: "Payroll Deposit 1763551 ON INC/", Title: "California Sandwiches", Category: "Wage", Subcategory: "Main" },
];

export default conversionRules;