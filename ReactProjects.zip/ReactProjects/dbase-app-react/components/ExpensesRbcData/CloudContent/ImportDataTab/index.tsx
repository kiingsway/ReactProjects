import React from "react";

export default function ImportDataTab(): React.JSX.Element {
  return (
    <div>ImportDataTab</div>
  );
}