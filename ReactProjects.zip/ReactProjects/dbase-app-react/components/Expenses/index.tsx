import React from "react";

export default function Expenses(): React.JSX.Element {
  return (
    <div>Expenses</div>
  );
}