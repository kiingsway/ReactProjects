import React from "react";

export default function CloudTable(): React.JSX.Element {
  return (
    <div>CloudTable</div>
  );
}