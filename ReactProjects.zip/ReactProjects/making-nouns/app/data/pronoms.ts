export const pronoms_simples: string[] = [
    "je",
    "tu",
    "il",
    "elle",
    "on",
    "nous",
    "vous",
    "ils",
    "elles"
];

export const pronoms: string[] = [
    "je",
    "tu",
    "il/elle/on",
    "nous",
    "vous",
    "ils/elles"
];

export default pronoms;