import React from 'react';

export default function Dashboard(): React.JSX.Element {
  return (
    <div>Dashboard</div>
  );
}