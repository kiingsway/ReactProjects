import React from 'react';

export default function Types(): React.JSX.Element {
  return (
    <div>Types</div>
  );
}