export const addctItems: string[] = [
  'B1',
  'F1',
  'Alcohol',
  'PhHs',
  'Alongar',
  'Exercícios',
  'Corrida/Caminhada',
  'Francês',
  'Patins',
];