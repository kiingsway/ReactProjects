import React from 'react';

export default function Settings(): React.JSX.Element {
  return (
    <div>Settings</div>
  );
}