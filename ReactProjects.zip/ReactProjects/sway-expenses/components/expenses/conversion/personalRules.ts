import { IConvertExpenseRule } from "@/interfaces";

const conversionRules: IConvertExpenseRule[] = [
  { match: "Monthly fee", Category: "Bank", Subcategory: "Fee" },
  { match: "Fee Electronic transaction", Category: "Bank", Subcategory: "Fee" },
  { match: "Fee - Electronic transaction", Category: "Bank", Subcategory: "Fee" },
  { match: "INTERAC e-Transfer fee", Title: "INTERAC Fee", Category: "Bank", Subcategory: "Fee" },
  { match: "Overdraft interest", Category: "Bank", Subcategory: "Fee" },
  { match: "ATM withdrawal", Title: "ATM withdrawal", Category: "Bank", Subcategory: "Withdrawal" },
  { match: "Online Transfer to Deposit Account", Category: "Bank", Subcategory: "Self Transfer" },

  { match: "WOODYS", Title: "Woody's", Category: "Rolês", Subcategory: "" },
  { match: "PAUPERS PUB", Title: "Paupers Pub", Category: "Rolês", Subcategory: "" },
  { match: "REBEL NIGHTCLUB", Title: "Rebel Nightclub", Category: "Rolês", Subcategory: "" },
  { match: "EVENTBRITE/QUEC", Title: "Eventbrite", Category: "Rolês", Subcategory: "" },
  { match: "TICKETWEB CANAD", Title: "Ticketweb Canada", Category: "Rolês", Subcategory: "" },

  { match: "NIAGARA SPEEDWA", Title: "Niagara Speedway", Category: "Travel/Vacation", Subcategory: "" },
  { match: "WONDERLAND", Title: "Canada's Wonderland", Category: "Travel/Vacation", Subcategory: "" },
  { match: "Needzappy Canad", Title: "Needzappy (Rent Charger)", Category: "Travel/Vacation", Subcategory: "" },

  { match: "MANDARIN YONGE", Title: "Mandarim", Category: "Rolês", Subcategory: "" },
  { match: "RIO 40 DEGREES", Title: "Rio 40 graus", Category: "Rolês", Subcategory: "" },
  { match: "MEZCALERO", Title: "Mezcalero", Category: "Rolês", Subcategory: "" },

  { match: "SQ *BAR VOLO", Title: "Mezcalero", Category: "Rolês", Subcategory: "" },
  { match: "SQ *BAR VOLO", Title: "Mezcalero", Category: "Rolês", Subcategory: "" },

  { match: "UPE EXPRESS PEA", Title: "Airport Express", Category: "Transport", Subcategory: "TTC" },
  { match: "ADA*VENDING MAC", Title: "Presto", Category: "Transport", Subcategory: "TTC" },
  { match: "PRES/", Title: "Presto", Category: "Transport", Subcategory: "TTC" },
  { match: "PRESTO ", Title: "Presto", Category: "Transport", Subcategory: "TTC" },

  { match: "LYFT", Title: "Lyft", Category: "Transport", Subcategory: "App" },
  { match: "UBER* PENDING", Title: "Uber", Category: "Transport", Subcategory: "App" },
  { match: "UBER* TRIP", Title: "Uber", Category: "Transport", Subcategory: "App" },

  { match: "LCBO/", Title: "LCBO", Category: "Drugs", Subcategory: "Alcohol" },
  { match: "THE BEER STORE", Title: "The Beer Store", Category: "Drugs", Subcategory: "Alcohol" },
  { match: "Wine Rack", Title: "Wine Rack", Category: "Drugs", Subcategory: "Alcohol" },

  { match: "THE HUNNY POT", Title: "The Hunny Pot", Category: "Drugs", Subcategory: "Weed" },
  { match: "THE BURNING BUS", Title: "The Burning Bush", Category: "Drugs", Subcategory: "Weed" },
  { match: "VALUE BUDS", Title: "Value Buds", Category: "Drugs", Subcategory: "Weed" },
  { match: "VALUD BUDS WEST", Title: "Value Buds", Category: "Drugs", Subcategory: "Weed" },
  { match: "FIKA LOCAL", Title: "Fika", Category: "Drugs", Subcategory: "Weed" },
  { match: "DAY N NITE CANN", Title: "Day N Nite", Category: "Drugs", Subcategory: "Weed" },
  { match: "HERB HUT", Title: "Herb Hut", Category: "Drugs", Subcategory: "Weed" },

  { match: "APPLE.COM/BILL", Title: "", Category: "Bills", Subcategory: "Subscription" },
  { match: "Amazon.ca Prime", Title: "Amazon Prime", Category: "Bills", Subcategory: "Subscription" },
  { match: "UBER CANADA", Title: "Uber (Ride/Eats)", Category: "Bills", Subcategory: "Subscription" },

  // Bills
  { match: "CANADIAN TIRE", Title: "Canadian Tire", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "aliexpress", Title: "Aliexpress", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "STAPLES", Title: "Staples", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "AMZN Mktp", Title: "Amazon", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "Amazon.ca", Title: "Amazon", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "PRICE WAR", Title: "Price War", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "STOP N GO", Title: "Stop N Go", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "ESSO CIRCLE", Title: "Esso Circle", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "CIRCLE K", Title: "Circle K", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "7 ELEVEN STORE", Title: "7 Eleven Store", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "DAMIANO'S NF", Title: "No Frills", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "GINO'S NF", Title: "No Frills", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "LISTRO'S NO FRI", Title: "No Frills", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "TONE TAI SUPERM", Title: "Tone Tai", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "FRESHCO", Title: "FreshCo", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "SAM'S FOOD STOR", Title: "Sam's Food", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "DOLLARAMA", Title: "Dollarama", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "COSTCO", Title: "Costco", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "WALMART", Title: "Walmart", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "LOBLAWS", Title: "Loblaws", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "GATEWAY NEWSSTA", Title: "Gateway Newsstand (Egl)", Category: "Groceries", Subcategory: "Market/Office" },
  { match: "THREE STAR VARI", Title: "Three Star Variety", Category: "Groceries", Subcategory: "Market/Office" },
  
  { match: "VALUE VILLAGE", Title: "Value Village", Category: "Clothing/Appearance", Subcategory: "" },

  { match: "CAPITAL ONE", Title: "Capital One", Category: "Bills", Subcategory: "Credit Card" },

  { match: "RAINBOW IDA PHA", Title: "Rainbow IDA Pharmacy", Category: "Bills", Subcategory: "Pharmacy" },
  { match: "SHOPPERS DRUG M", Title: "Shoppers", Category: "Bills", Subcategory: "Pharmacy" },
  { match: "BATH - BODY WOR", Title: "Bath Body Works", Category: "Bills", Subcategory: "Pharmacy" },



  { match: "FREEDOM MOBILE", Title: "Freedom Mobile", Category: "Bills", Subcategory: "Cellular" },

  { match: "SAINT GERMAIN B", Title: "Saint Germain Bakery", Category: "Groceries", Subcategory: "App" },
  { match: "SEGOVIA MEAT MA", Category: "Groceries", Subcategory: "App" },
  { match: "STOP BBQ CHICKE", Title: "Stop BBQ Chicken", Category: "Groceries", Subcategory: "App" },
  { match: "BURGER KING", Title: "Burguer King", Category: "Groceries", Subcategory: "App" },
  { match: "OSMOWS", Title: "Osmow's", Category: "Groceries", Subcategory: "App" },
  { match: "MCDONALD'S", Title: "McDonald's", Category: "Groceries", Subcategory: "App" },
  { match: "UBER* EATS", Title: "Uber Eats", Category: "Groceries", Subcategory: "App" },
  { match: "DOORDASH", Title: "DoorDash", Category: "Groceries", Subcategory: "App" },
  { match: "WENDYS 6758", Title: "Wendy's", Category: "Groceries", Subcategory: "App" },
  { match: "NYF3234", Title: "New York Fries", Category: "Groceries", Subcategory: "App" },
  { match: "SQ *HAPPY BURGE", Title: "Happy Burger", Category: "Groceries", Subcategory: "App" },
  { match: "STARBUCKS COFFE", Title: "Starbucks", Category: "Groceries", Subcategory: "App" },
  { match: "TACO BELL", Title: "Taco Bell", Category: "Groceries", Subcategory: "App" },
  { match: "ROLL STAR SUSHI", Title: "Roll Star Sushi", Category: "Groceries", Subcategory: "App" },
  { match: "PIZZA PIZZA", Title: "Pizza Pizza", Category: "Groceries", Subcategory: "App" },
  { match: "TIM HORTONS", Title: "Tim Hortons", Category: "Groceries", Subcategory: "App" },
  { match: "OLD.K CHICKEN", Title: "Old K Chicken", Category: "Groceries", Subcategory: "App" },
  { match: "JIMMY THE GREEK", Title: "Jimmy The Greek", Category: "Groceries", Subcategory: "App" },

  { match: "Payroll Deposit - SPOT", Title: "SpotDog", Category: "Wage", Subcategory: "App" },
  { match: "Payroll Deposit SPOT", Title: "SpotDog", Category: "Wage", Subcategory: "App" },
  { match: "Deposit interest", Category: "Wage", Subcategory: "Investment" },
  { match: "Bonus deposit interest", Category: "Wage", Subcategory: "Investment" },
  { match: "ON INC/", Title: "California Sandwiches", Category: "Wage", Subcategory: "Main" },

  { match: "GREAT CANADIAN", Category: "Others", Subcategory: "" },
  { match: "SQ *BINI TATTOO", Category: "Clothing/Appearance", Subcategory: "" },
];

export default conversionRules;