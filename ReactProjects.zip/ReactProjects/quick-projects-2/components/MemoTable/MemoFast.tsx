import React from 'react';

export default function MemoFast(): React.JSX.Element {
  return (
    <div>MemoFast</div>
  );
}