import React from 'react';

export default function MemoSlow(): React.JSX.Element {
  return (
    <div>MemoSlow</div>
  );
}