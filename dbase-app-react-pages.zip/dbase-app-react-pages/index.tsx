import React from 'react';

export default function Home(): React.JSX.Element {

  async function getItems() {
    try {
      const res = await fetch('/api/get_database');
      const data = await res.json();
      console.log('Dados do Notion:', data);
    } catch (err) {
      console.error('Erro ao buscar:', err);
    }
  }

  async function fetchItems() {
    try {
      const res = await fetch('/api/fetch-database');
      const data = await res.json();
      console.log('Dados do Notion:', data);
    } catch (err) {
      console.error('Erro ao buscar:', err);
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen flex-col">
      <button onClick={getItems}>Get Database</button>
      <button onClick={fetchItems}>Fetch Items</button>
    </div>
  );
}