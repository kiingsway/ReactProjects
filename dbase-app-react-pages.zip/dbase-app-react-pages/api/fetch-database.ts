import type { NextApiRequest, NextApiResponse } from "next";
import { Client } from "@notionhq/client";

const notion = new Client({ auth: process.env.NEXT_PUBLIC_NOTION_TOKEN });
const databaseId = process.env.NEXT_PUBLIC_DATABASE_ID as string;

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (!databaseId) {
    return res.status(500).json({ error: "Missing Notion database ID" });
  }

  try {
    const response = await notion.databases.query({
      database_id: databaseId,
      filter: {
        property: "Last ordered",
        date: {
          after: "2022-12-31",
        },
      },
    });

    res.status(200).json(response.results);
  } catch (error: any) {
    console.error("Error querying Notion:", error);
    res.status(500).json({ error: error.message || "Unknown error" });
  }
}


// pages/api/databases.ts