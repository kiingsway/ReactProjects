import type { NextApiRequest, NextApiResponse } from "next";
import { Client } from "@notionhq/client";

const notion = new Client({ auth: process.env.NEXT_PUBLIC_NOTION_TOKEN });

export default async function handler(_req: NextApiRequest, res: NextApiResponse) {
  try {
    const databases = [];
    let cursor: string | undefined = undefined;

    do {
      const response = await notion.search({
        filter: {
          property: "object",
          value: "database",
        },
        start_cursor: cursor,
        page_size: 100,
      });

      databases.push(...response.results);
      cursor = response.next_cursor || undefined;
    } while (cursor);

    res.status(200).json(databases);
  } catch (e: unknown) {
    let error = "Erro desconhecido";

    if (e instanceof Error) {
      console.error("Erro ao buscar databases: ", e.message);
      error = e.message;
    } else {
      console.error("Erro não identificado: ", e);
    }

    res.status(500).json({ error });
  }
}
